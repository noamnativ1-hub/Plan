import * as React from "react"

import { cn } from "@/lib/utils"

function EmptyPlaceholder({
  className,
  children,
  ...props
}) {
  return (
    <div
      className={cn(
        "flex min-h-[400px] flex-col items-center justify-center rounded-md border border-dashed p-8 text-center animate-in fade-in-50",
        className
      )}
      {...props}
    >
      <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
        {children}
      </div>
    </div>
  )
}

export { EmptyPlaceholder }